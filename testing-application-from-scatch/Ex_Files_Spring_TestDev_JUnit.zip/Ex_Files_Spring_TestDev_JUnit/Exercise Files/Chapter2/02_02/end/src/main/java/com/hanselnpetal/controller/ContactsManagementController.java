package com.hanselnpetal.controller;

public class ContactsManagementController {

}

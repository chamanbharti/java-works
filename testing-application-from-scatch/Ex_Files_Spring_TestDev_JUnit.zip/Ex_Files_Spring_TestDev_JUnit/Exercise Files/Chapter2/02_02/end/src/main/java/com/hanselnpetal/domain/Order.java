package com.hanselnpetal.domain;

public class Order {

}

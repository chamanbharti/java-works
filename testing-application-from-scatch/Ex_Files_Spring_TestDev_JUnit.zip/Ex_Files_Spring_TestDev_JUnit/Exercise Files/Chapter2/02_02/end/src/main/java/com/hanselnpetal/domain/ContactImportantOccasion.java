package com.hanselnpetal.domain;

public class ContactImportantOccasion {

}

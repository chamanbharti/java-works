Ext.define('Student',
    {
       // extend: 'Person',
        schoolName: '',

        constructor: function(schoolName){
            this.schoolName = schoolName;
        },
        mixins: {
            eat: 'Person'
        },
        getSchoolName: function(){
          document.write('I am a student of '+this.schoolName)
        }
    }
);
var studentObj = new Ext.create('Student', 'XYZ');
studentObj.eat('Sandwich');
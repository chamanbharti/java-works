Ext.define('Person', {
    name: 'Unknown',
    constructor: function(name){
        if(name){
            this.name=name;
        }
    },
    getName: function() {
        alert('My name is '+this.name);
    },
    eat: function(){
        document.write('<br>Person Class Eat Method');
    }
});
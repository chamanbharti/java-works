Ext.define('Student2',
    {
       config:
       {
           name: 'unnamed',
           schoolName: 'unknown'
       },

        constructor: function(config){
            this.initConfig(config);
        },
        applyName: function(name){
            return Ext.String.capitalize(name);
        },
        updateName: function(newValue,oldValue){
            alert('New Value:'+newValue+',Old Value:'+oldValue);
        }
     }
);
var newStudent = Ext.create('Student2', 
    {name: 'xyz',schoolName: 'abc school'}
);
newStudent.setName('Chaman');
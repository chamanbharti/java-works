Ext.define('Student',
    {
       config:
       {
           name: 'unnamed',
           schoolName: 'unknown'
       }
    //    ,

    //     constructor: function(config){
    //         this.initConfig(config);
    //     }
     }
);
Ext.define('Student', {
    config: {
        name: ''
    },
    mixins: {
        observable: 'Ext.util.Observable'
    },
    constructor: function(config){
    this.mixins.observable.constructor.call(this,config);
    },
    updateName: function(newValue, oldValue){
        this.fireEvent('studentNameChanged', newValue)
    }
});

var student = Ext.create('Student',{name:'xyz'});
student.on('studentNameChanged',function(name){
    alert('student name '+name+' has been changed.');
});
student.setName('Chaman');
Ext.define('CustomClasses.Student2',
    {
        name: 'Unknown',
        constructor: function(studentName){
            if(studentName)
             this.name = studentName;
        },
        getName: function(){
            alert('Student name is '+this.name)
        },
        statics:
        {
            MAXVALUE: 1000,
            getSchoolName: function(){
                return 'XYZ from static function';
            }
        }
    }
);
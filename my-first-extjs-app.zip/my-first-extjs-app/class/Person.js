Ext.define('Person', {
    name: 'Unknown',
    constructor: function(name){
        if(name){
            this.name=name;
        }
    },
    getName: function() {
        alert('My name is '+this.name);
    }
});
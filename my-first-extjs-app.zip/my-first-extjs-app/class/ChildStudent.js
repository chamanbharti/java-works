Ext.define('ChildStudent', {
    extend: 'Person',
    schoolName: 'Unknown',

    constructor: function(name, schoolName){
        this.schoolName = schoolName || 'Unknown';
        //call parent constructor
        this.callParent(arguments);
    },
    getSchoolName: function(){
        alert('My school name is '+this.schoolName);
    }
})
Ext.define('UserPanel',
{
    constructor: function(){
        this.createPanel();
    },

    seeStatusHandler: function(){
        document.getElementById('div1').innerHTML = "You have selected";
        var status = Ext.getCmp('checkbox1').getValue();
        if(status)
            document.getElementById('div1').innerHTML += ' '+Ext.getCmp('checkbox1').boxLabel;
        
        status = Ext.getCmp('checkbox2').getValue();   
        if(status)
            document.getElementById('div1').innerHTML += ' '+Ext.getCmp('checkbox2').boxLabel;
        
        status = Ext.getCmp('checkbox3').getValue();   
        if(status)
            document.getElementById('div1').innerHTML += ' '+Ext.getCmp('checkbox3').boxLabel; 
    },

    selectAllHandler: function(){
        Ext.getCmp('checkbox1').getValue(true);
        Ext.getCmp('checkbox2').getValue(true);
        Ext.getCmp('checkbox3').getValue(true);
    },

    deSelectAllHandler: function(){
        Ext.getCmp('checkbox1').getValue(false);
        Ext.getCmp('checkbox2').getValue(false);
        Ext.getCmp('checkbox3').getValue(false);
    },

    createPanel: function() {
        this.userPanel = Ext.create('Ext.form.Panel',{
            bodyPadding: 10,
            width: 100,
            id: 'userPanel',
            title: 'Ext JS Check Box Demo',

            items: [
                {
                    xtype: 'fieldcontainer',
                    fieldLabel: 'Select technology',
                    defaultType: 'checkboxfield',
                    items: [
           
                     {
                       boxLabel: 'Java',
                       name: 'technology',
                       inputValue: '1',
                       id: 'checkbox1'
                     },
           
                     {
                       boxLabel: 'Angular',
                       name: 'technology',
                       inputValue: '2',
                       checked: true,
                       id: 'checkbox2'
                     },
           
                     {
                       boxLabel: 'Microservices',
                       name: 'technology',
                       inputValue: '3',
                       id: 'checkbox3'
                     }
                    ]
                  }

            ],

            bbar: [
                {
                    text: 'See Status',
                    handler: this.seeStatusHandler
                },
                {
                    text: 'Select All',
                    handler: this.selectAllHandler
                },
                {
                    text: 'Deselect All',
                    handler: this.deSelectAllHandler
                }
            ],
            renderTo: Ext.getBody()
        });
    }
});